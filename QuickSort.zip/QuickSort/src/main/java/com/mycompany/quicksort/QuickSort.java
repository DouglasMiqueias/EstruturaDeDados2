/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.quicksort;

/**
 *
 * @author Iftm
 */
public class QuickSort {

    public static void main(String[] args) {
        int[] vetor = {64, 25, 12, 22, 11};

        System.out.println("=== QUICK SORT - ORDENAÇÃO CRESCENTE ===\n");
        System.out.print("Vetor ANTES da ordenação: ");
        imprimirVetor(vetor);

        quickSort(vetor, 0, vetor.length - 1);

        System.out.print("\nVetor DEPOIS da ordenação: ");
        imprimirVetor(vetor);
        System.out.println("\n=== FIM ===");
    }

    // Método principal recursivo do Quick Sort
    static void quickSort(int[] vetor, int inicio, int fim) {
        if (inicio < fim) {
            System.out.println("\n--- Chamada quickSort: índices [" + inicio + " .. " + fim + "] ---");
            System.out.print("    Subvetor atual: ");
            imprimirSubvetor(vetor, inicio, fim);

            int indicePivo = particionar(vetor, inicio, fim);

            System.out.println("    Pivô fixado na posição " + indicePivo
                    + " (valor: " + vetor[indicePivo] + ")");

            // Recursão na partição esquerda (menores que o pivô)
            quickSort(vetor, inicio, indicePivo - 1);
            // Recursão na partição direita (maiores que o pivô)
            quickSort(vetor, indicePivo + 1, fim);
        }
    }

    // Particionamento: escolhe o último elemento como pivô,
    // move menores para a esquerda e maiores para a direita.
    static int particionar(int[] vetor, int inicio, int fim) {
        int pivo = vetor[fim];
        System.out.println("    Pivô escolhido: " + pivo + " (posição " + fim + ")");

        int i = inicio - 1; // índice do último elemento menor que o pivô

        for (int j = inicio; j < fim; j++) {
            System.out.print("      Comparando vetor[" + j + "]=" + vetor[j]
                    + " com pivô=" + pivo + " → ");

            if (vetor[j] <= pivo) {
                i++;
                System.out.print(vetor[j] + " <= " + pivo);

                if (i != j) {
                    trocar(vetor, i, j);
                    System.out.print(" | TROCA: posição " + i + " ↔ posição " + j);
                } else {
                    System.out.print(" | sem troca necessária");
                }
                System.out.print(" → ");
                imprimirSubvetor(vetor, inicio, fim);
            } else {
                System.out.println(vetor[j] + " > " + pivo + " | mantém posição");
            }
        }

        // Coloca o pivô na posição correta
        trocar(vetor, i + 1, fim);
        System.out.print("      Pivô " + pivo + " posicionado: TROCA posição "
                + (i + 1) + " ↔ posição " + fim + " → ");
        imprimirSubvetor(vetor, inicio, fim);

        return i + 1;
    }

    // Troca dois elementos no vetor
    static void trocar(int[] vetor, int a, int b) {
        int temp = vetor[a];
        vetor[a] = vetor[b];
        vetor[b] = temp;
    }

    // Imprime o vetor inteiro
    static void imprimirVetor(int[] vetor) {
        System.out.print("[");
        for (int i = 0; i < vetor.length; i++) {
            System.out.print(vetor[i]);
            if (i < vetor.length - 1) System.out.print(", ");
        }
        System.out.println("]");
    }

    // Imprime apenas uma fatia do vetor (subvetor)
    static void imprimirSubvetor(int[] vetor, int inicio, int fim) {
        System.out.print("[");
        for (int i = inicio; i <= fim; i++) {
            System.out.print(vetor[i]);
            if (i < fim) System.out.print(", ");
        }
        System.out.println("]");
    }
}